<<<<<<< HEAD
#!/bin/bash
#Tukaj nekaj izpišemo
echo "Ali boš uspel rešiti to nalogo?"
=======
#!/bin/bash

echo "Ali boš uspel rešiti ta problem?"
>>>>>>> reserve
