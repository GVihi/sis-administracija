free -m > /dev/kmsg
