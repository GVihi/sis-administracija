#!/bin/bash
while true
do
    w > /dev/kmsg
    sleep 5
done
